// The Wilder – Main JS + Motion

document.addEventListener('DOMContentLoaded', () => {
  // Navbar scroll
  const navbar = document.getElementById('navbar');
  if (navbar) {
    const onScroll = () => {
      navbar.classList.toggle('scrolled', window.scrollY > 60);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  // Mobile menu
  const menuBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  if (menuBtn && mobileMenu) {
    menuBtn.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));
  }

  // Contact form
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const success = document.getElementById('form-success');
      if (success) {
        success.classList.remove('hidden');
        form.reset();
        setTimeout(() => success.classList.add('hidden'), 5000);
      }
    });
  }

  // ===== Hero floating particles =====
  const hero = document.querySelector('.hero-section');
  if (hero) {
    for (let i = 0; i < 18; i++) {
      const p = document.createElement('div');
      p.className = 'hero-particle';
      p.style.left = Math.random() * 100 + '%';
      p.style.bottom = '-10px';
      p.style.animationDuration = (8 + Math.random() * 12) + 's';
      p.style.animationDelay = (Math.random() * 8) + 's';
      p.style.width = p.style.height = (3 + Math.random() * 5) + 'px';
      hero.appendChild(p);
    }
  }

  // ===== Split-image assemble on scroll =====
  const splitSection = document.querySelector('.split-section');
  if (splitSection) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting && entry.intersectionRatio > 0.35) {
            splitSection.classList.add('assembled');
          }
        });
      },
      { threshold: [0.2, 0.35, 0.5] }
    );
    observer.observe(splitSection);

    window.addEventListener('scroll', () => {
      const rect = splitSection.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.55 && rect.bottom > 100) {
        splitSection.classList.add('assembled');
      }
    }, { passive: true });
  }
});
