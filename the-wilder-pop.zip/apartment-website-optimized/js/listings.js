// Listings filter & sort logic

document.addEventListener('DOMContentLoaded', () => {
  const priceRange = document.getElementById('price-range');
  const priceValue = document.getElementById('price-value');
  const bedChecks = document.querySelectorAll('.filter-bed');
  const cards = document.querySelectorAll('.property-card');
  const resultCount = document.getElementById('result-count');
  const sortSelect = document.getElementById('sort-select');
  const resetBtn = document.getElementById('reset-filters');

  function updatePriceLabel() {
    if (priceRange && priceValue) {
      const val = parseInt(priceRange.value);
      priceValue.textContent = val >= 7000 ? 'Any price' : `Up to $${val.toLocaleString()}`;
    }
  }

  function filterAndSort() {
    const maxPrice = priceRange ? parseInt(priceRange.value) : 99999;
    const selectedBeds = Array.from(bedChecks)
      .filter(c => c.checked)
      .map(c => c.value);

    let visible = [];

    cards.forEach(card => {
      const beds = card.dataset.beds;
      const price = parseInt(card.dataset.price) || 0;

      const bedMatch = selectedBeds.length === 0 || selectedBeds.includes(beds);
      const priceMatch = price <= maxPrice;

      if (bedMatch && priceMatch) {
        card.style.display = '';
        visible.push(card);
      } else {
        card.style.display = 'none';
      }
    });

    // Sort
    if (sortSelect) {
      const sort = sortSelect.value;
      const grid = document.getElementById('listings-grid');
      visible.sort((a, b) => {
        const pa = parseInt(a.dataset.price);
        const pb = parseInt(b.dataset.price);
        const sa = parseInt(a.dataset.size);
        const sb = parseInt(b.dataset.size);
        if (sort === 'price-asc') return pa - pb;
        if (sort === 'price-desc') return pb - pa;
        if (sort === 'size') return sb - sa;
        return 0; // featured order
      });
      visible.forEach(c => grid.appendChild(c));
    }

    if (resultCount) {
      resultCount.textContent = visible.length;
    }
  }

  if (priceRange) {
    priceRange.addEventListener('input', () => {
      updatePriceLabel();
      filterAndSort();
    });
    updatePriceLabel();
  }

  bedChecks.forEach(c => c.addEventListener('change', filterAndSort));
  if (sortSelect) sortSelect.addEventListener('change', filterAndSort);

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      bedChecks.forEach(c => c.checked = false);
      if (priceRange) {
        priceRange.value = 7000;
        updatePriceLabel();
      }
      filterAndSort();
    });
  }

  filterAndSort();
});
